@echo off
set "ROOT=%~dp0"
start "Backend" powershell -NoExit -ExecutionPolicy Bypass -File "%ROOT%start-backend.ps1"
start "Frontend" powershell -NoExit -ExecutionPolicy Bypass -File "%ROOT%start-frontend.ps1"
echo Frontend: http://localhost:5173
echo Backend:  http://localhost:8000
echo API Docs: http://localhost:8000/docs
