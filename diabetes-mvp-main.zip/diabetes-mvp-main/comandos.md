# Comandos para ejecutar el proyecto (Windows / PowerShell)

Se asume que ya completaste la instalación: Python 3.11, Node.js, `backend\venv` con las dependencias y `frontend\node_modules`.
Ajusta `C:\proyectos\diabetes-mvp-main` a la ruta real del proyecto en tu equipo.

## Ejecutar (opción rápida)
```powershell
cd C:\proyectos\diabetes-mvp-main
.\start-all.bat
```
Abre dos ventanas: una con el backend (puerto 8000) y otra con el frontend (puerto 5173).

## Ejecutar (manual, dos terminales)

Terminal 1 (backend):
```powershell
cd C:\proyectos\diabetes-mvp-main\backend
.\venv\Scripts\Activate.ps1
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
Si PowerShell bloquea el script: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`

Terminal 2 (frontend):
```powershell
cd C:\proyectos\diabetes-mvp-main\frontend
npm.cmd run dev
```

## Verificar
1. http://localhost:8000/api/health responde `{"status":"healthy",...}`.
2. http://localhost:5173 muestra el login.
3. La consola del backend muestra "Database tables created/verified".

## URLs
- Frontend: http://localhost:5173
- Backend: http://localhost:8000
- Docs API: http://localhost:8000/docs

## Credenciales
| Usuario | Contraseña | Rol |
|---|---|---|
| admin | admin123 | admin |
| enfermera | enfermera123 | nurse |
| nutricionista | nutricionista123 | nutritionist |

## Detener
`Ctrl + C` en cada terminal (o cerrar las ventanas abiertas por `start-all.bat`).

## Opcionales

Datos de ejemplo (5 pacientes; BORRA todos los datos actuales de la BD):
```powershell
cd C:\proyectos\diabetes-mvp-main\backend
.\venv\Scripts\Activate.ps1
python init_db.py
```

Simulador de glucómetro BLE (con el backend encendido, en una tercera terminal):
```powershell
cd C:\proyectos\diabetes-mvp-main\backend
.\venv\Scripts\Activate.ps1
python -m ble_service.simulator
```

Pruebas Epic 04 (venv activo, desde `backend\`):
```powershell
python ..\scripts\test_epic04_inline.py
```

Entrenar el modelo (NO necesario; solo con `requirements.txt` completo y TensorFlow):
```powershell
cd C:\proyectos\diabetes-mvp-main\backend
.\venv\Scripts\Activate.ps1
python train_model.py
```

## Problemas frecuentes
- `ModuleNotFoundError`: el venv no está activo (`.\venv\Scripts\Activate.ps1`).
- Ejecuta siempre el backend desde la carpeta `backend\`; desde otra crea una BD vacía.
- Frontend con "No se pudo conectar con el servidor": el backend no está corriendo en el puerto 8000.
- `The asyncio extension requires an async driver`: en `backend\.env`, `DIABETES_MVP_DATABASE_URL` debe ser `sqlite+aiosqlite:///./diabetes_mvp.db`.
- `Port 8000 is already in use`: cierra el proceso que lo usa.
