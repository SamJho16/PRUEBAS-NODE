# Soluciones: paso a paso (equipo con internet)

La computadora donde se hará todo tiene internet, así que se puede descargar e instalar lo necesario.
Los comandos están en PowerShell. Los detalles de ejecución diaria están en `comandos.md`.

## Estado actual

### Ya resuelto en el código (no tienes que hacerlo)
| # | Pendiente original | Resuelto con |
|---|---|---|
| 1 | Dependencias ligeras sin TensorFlow/SHAP | `backend/requirements-minimal.txt` |
| 2 | Puerto 8100 en `run.sh` (debía ser 8000) | `backend/run.sh` corregido |
| 3 | Falta archivo `.env` | `backend/.env` creado; `.env.example` corregido (`sqlite+aiosqlite`) |
| 4 | Scripts bash no sirven en Windows | `start-backend.ps1`, `start-frontend.ps1`, `start-all.bat` |
| 5 | `start.sh` no soportaba `venv\Scripts` | `start.sh` corregido |
| 6 | Usuario `enfermera` no se creaba solo | `backend/app/main.py` lo crea al arrancar |
| 7 | Scripts de prueba con rutas `/home/z/...` y `requests` | `scripts/test_epic04*.py` corregidos |
| 8 | Documentación desactualizada | `Leeme.txt` y `comandos.md` actualizados |

### Lo que falta y debes hacer tú (pasos 1 a 9)
Instalar programas y dependencias, ejecutar y probar. Nada de esto se ha ejecutado todavía, por lo que los cambios del código aún no están verificados.

---

## Paso 1. Instalar Python 3.11 [TÚ]
Se recomienda 3.11 (64 bits): TensorFlow 2.15 y `numpy==1.24.3` no soportan 3.12 o superior.

Opción A (winget):
```powershell
winget install -e --id Python.Python.3.11
```
Opción B: descargar el instalador de https://www.python.org/downloads/windows/ (versión 3.11.x) y marcar "Add python.exe to PATH".

Cierra y abre PowerShell, y verifica:
```powershell
python --version
```
Debe mostrar `Python 3.11.x`. Si tienes varias versiones, usa `py -3.11` en lugar de `python` para crear el venv.

## Paso 2. Instalar Node.js [TÚ]
```powershell
winget install -e --id OpenJS.NodeJS.LTS
```
O descargar el instalador LTS desde https://nodejs.org. Reabre PowerShell y verifica:
```powershell
node --version
npm.cmd --version
```

## Paso 3. Copiar el proyecto [TÚ]
Copia la carpeta `diabetes-mvp-main` completa a la otra computadora (USB, nube o Git). No copies `venv` ni `node_modules` si existieran. Ejemplo de ruta usada abajo: `C:\proyectos\diabetes-mvp-main`.

## Paso 4. Backend: entorno virtual y dependencias [TÚ]
```powershell
cd C:\proyectos\diabetes-mvp-main\backend
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```
Si PowerShell bloquea el script:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Elige una opción:

**Opción recomendada para empezar (rápida, sin TensorFlow, predicción heurística):**
```powershell
pip install -r requirements-minimal.txt
```

**Opción completa (modelo CNN-LSTM, SHAP y BLE):**
```powershell
pip install -r requirements.txt
```
Para la completa necesitas:
- Python 3.9 a 3.11.
- Microsoft Visual C++ Redistributable 2015-2022 (x64): `winget install -e --id Microsoft.VCRedist.2015+.x64`.
- Rutas cortas o rutas largas habilitadas en Windows si el instalador falla por nombres de archivo largos.
- Varios GB libres y tiempo de descarga (TensorFlow es pesado).

Verifica:
```powershell
python -c "import fastapi, sqlalchemy, aiosqlite, passlib, jose; print('backend OK')"
```

## Paso 5. Frontend: dependencias [TÚ]
```powershell
cd C:\proyectos\diabetes-mvp-main\frontend
npm.cmd install
```
Se creará `node_modules`. Verifica con `npm.cmd run build` (opcional, comprueba que compila).

## Paso 6. Decidir sobre la base de datos [TÚ]
`backend\diabetes_mvp.db` ya existe. Elige una:
- Conservarla: no hagas nada. Al arrancar se crean las tablas faltantes y los usuarios `admin`, `nutricionista` y `enfermera`.
- Reiniciarla con 5 pacientes de ejemplo (BORRA todos los datos actuales):
```powershell
cd C:\proyectos\diabetes-mvp-main\backend
.\venv\Scripts\Activate.ps1
python init_db.py
```
Si es una instalación nueva y quieres datos de ejemplo, usa la segunda opción.

## Paso 7. Ejecutar el proyecto [TÚ]
Con un solo comando:
```powershell
cd C:\proyectos\diabetes-mvp-main
.\start-all.bat
```
O manual, en dos terminales:
```powershell
# Terminal 1
cd C:\proyectos\diabetes-mvp-main\backend
.\venv\Scripts\Activate.ps1
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
```powershell
# Terminal 2
cd C:\proyectos\diabetes-mvp-main\frontend
npm.cmd run dev
```

## Paso 8. Verificar que funciona [TÚ]
1. http://localhost:8000/api/health debe devolver `{"status":"healthy",...}`.
2. http://localhost:8000/docs muestra la documentación de la API.
3. http://localhost:5173: iniciar sesión con `admin / admin123`; probar también `enfermera / enfermera123` y `nutricionista / nutricionista123`.
4. En el backend, la consola debe mostrar "Database tables created/verified".

Pruebas automáticas de Epic 04 (con el venv activo, desde `backend\`):
```powershell
python ..\scripts\test_epic04_inline.py
```
Si falla, copia el error completo y envíamelo para corregirlo; estos cambios aún no se han ejecutado.

## Paso 9. Opcional: entrenar el modelo CNN-LSTM [TÚ]
Solo si instalaste `requirements.txt` completo.
```powershell
cd C:\proyectos\diabetes-mvp-main\backend
.\venv\Scripts\Activate.ps1
python train_model.py
```
Genera `backend\model\cnn_lstm_diabetes\`. Reinicia el backend para que lo cargue (el log mostrará "ML model loaded"). Si el equipo es poco potente, reduce en `train_model.py` (función `main`): `epochs=50` a `15`, `n_augment=3` a `1`, `n_folds=3` a `2`.

## Paso 10. Antes de un uso real [TÚ]
- Cambiar `DIABETES_MVP_SECRET_KEY` en `backend\.env` por un valor largo y aleatorio.
- Cambiar las contraseñas por defecto (`admin123`, etc.).
- Opcional: simulador BLE con `python -m ble_service.simulator` (desde `backend\`, con venv activo). Para un glucómetro real se necesita `bleak` (incluido en `requirements.txt`) y Bluetooth en el equipo.

---

## Errores comunes y solución
| Error | Causa | Solución |
|---|---|---|
| `pip install -r requirements.txt` falla con tensorflow/numpy | Python 3.12 o superior | Instalar Python 3.11 y recrear el venv, o usar `requirements-minimal.txt` |
| `The asyncio extension requires an async driver` | `DATABASE_URL` sin `+aiosqlite` | Usar `sqlite+aiosqlite:///./diabetes_mvp.db` en `.env` |
| `ModuleNotFoundError` | venv no activo | `.\venv\Scripts\Activate.ps1` |
| `Activate.ps1 cannot be loaded` | Política de ejecución | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| Frontend: "No se pudo conectar con el servidor" | Backend apagado o en otro puerto | Iniciar backend en el puerto 8000 |
| Login falla con `enfermera` | BD antigua sin ese usuario | Reiniciar el backend (lo crea) o ejecutar `init_db.py` |
| `Port 8000 is already in use` | Otro proceso usa el puerto | Cerrarlo o cambiar el puerto (y el proxy en `frontend/vite.config.js`) |
| Error al instalar TensorFlow por ruta larga | Límite de 260 caracteres de Windows | Habilitar rutas largas o mover el proyecto a una ruta corta |
