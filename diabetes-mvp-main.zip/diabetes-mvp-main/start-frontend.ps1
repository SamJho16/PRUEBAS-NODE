$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "frontend")

if (-not (Test-Path ".\node_modules")) {
    Write-Host "No existe frontend\node_modules. Copialo desde otro equipo o ejecuta npm.cmd install." -ForegroundColor Red
    exit 1
}

npm.cmd run dev
