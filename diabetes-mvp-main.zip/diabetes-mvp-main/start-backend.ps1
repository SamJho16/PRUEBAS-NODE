$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "backend")

if (-not (Test-Path ".\venv\Scripts\Activate.ps1")) {
    Write-Host "No existe backend\venv. Crealo con: python -m venv venv" -ForegroundColor Red
    exit 1
}

. .\venv\Scripts\Activate.ps1
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
