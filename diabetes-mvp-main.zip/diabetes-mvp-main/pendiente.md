# Pendiente para que el proyecto se ejecute correctamente

Análisis basado en la lectura del código (no se instaló ni ejecutó nada).

## Bloqueantes / probables fallos

1. **No existe entorno virtual ni dependencias instaladas.** No hay `backend/venv` y el frontend no tiene `node_modules`. Hay que ejecutar `pip install -r requirements.txt` y `npm.cmd install`.
2. **Versión de Python.** `tensorflow==2.15.0` y `numpy==1.24.3` solo funcionan con Python 3.9–3.11. Con Python 3.12+ `pip install -r requirements.txt` falla. Opciones: usar Python 3.11, o quitar `tensorflow` y `shap` del requirements (el backend funciona con scoring heurístico sin ellos).
3. **`start.sh` y `run.sh` son scripts bash.** En Windows no corren en PowerShell. Además usan `venv/bin/activate`, que en Windows es `venv\Scripts\activate`. Hay que usar los comandos manuales de `comandos.md` o Git Bash/WSL.
4. **Inconsistencia de puertos.** `backend/run.sh` arranca en el puerto **8100**, pero el proxy de Vite ([frontend/vite.config.js](frontend/vite.config.js)) y CORS apuntan al **8000**. Usar siempre el 8000.
5. **Archivo `.env` inexistente.** Solo existe `backend/.env.example`. No es obligatorio (hay valores por defecto), pero conviene copiarlo y cambiar `SECRET_KEY`. Las variables llevan prefijo `DIABETES_MVP_`.
6. **Modelo ML no entrenado.** No existe `backend/model/cnn_lstm_diabetes/`. El backend usa el cálculo heurístico, así que no falla, pero las predicciones no usan la red CNN-LSTM. Para usarla: `python train_model.py` (requiere TensorFlow).

## Problemas menores / riesgos

7. **`init_db.py` borra todos los datos** (`drop_all`). Ya existe `backend/diabetes_mvp.db`; no lo ejecutes si quieres conservarla. Además `start.sh` solo lo llama si la BD no existe.
8. **Usuario `enfermera` posiblemente inexistente.** Al arrancar, el backend solo crea `admin` y `nutricionista`. `enfermera` solo la crea `init_db.py`. Las pruebas de Epic 04 y la documentación lo usan, así que confirma que la BD existente lo tenga.
9. **`Leeme.txt` desactualizado.** Usa rutas `D:\diabetes-mvp\...` y `/home/z/my-project/scripts/...` que no coinciden con tu carpeta.
10. **`scripts/test_epic04.py` usa `requests`,** que no está en `requirements.txt` (hace falta instalarlo solo para ese script). `test_epic04_inline.py` usa `TestClient` de FastAPI, que necesita `httpx` (sí está incluido) y debe ejecutarse desde `backend/` para que `import app` funcione.
11. **`bleak` (BLE).** Solo se necesita para `ble_service.main` (glucómetro real). El simulador (`ble_service.simulator`) no lo requiere, pero ambos escriben directo en SQLite, así que el backend y la BD deben estar en la misma ruta (`backend/diabetes_mvp.db`).
12. **`DATABASE_URL` relativa** (`./diabetes_mvp.db`). El backend debe iniciarse siempre desde la carpeta `backend/`, o creará una BD vacía en otra ubicación.
13. **Seguridad (solo para producción).** `SECRET_KEY` por defecto y credenciales por defecto (`admin/admin123`) deben cambiarse.
14. **Sin pruebas automatizadas ni `README` formal.** Solo hay scripts de prueba manuales en `scripts/`.

## Orden mínimo recomendado
1. Verificar `python --version` (3.10/3.11) y `node --version`.
2. Crear venv e instalar `requirements.txt`.
3. Instalar dependencias del frontend.
4. Levantar backend (puerto 8000) y luego frontend (puerto 5173).
5. Entrar a http://localhost:5173 con `admin / admin123`.
