#!/bin/bash
cd "$(dirname "$0")"
if [ -f venv/bin/activate ]; then
    source venv/bin/activate
else
    source venv/Scripts/activate
fi
exec python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --timeout-keep-alive 300
